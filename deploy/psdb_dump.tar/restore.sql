--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.purchases DROP CONSTRAINT purchases_user_id_fkey;
ALTER TABLE ONLY public.purchase_items DROP CONSTRAINT purchase_items_purchase_id_fkey;
ALTER TABLE ONLY public.purchase_items DROP CONSTRAINT purchase_items_product_id_fkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.purchases DROP CONSTRAINT purchases_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.purchases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.purchase_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.purchases_id_seq;
DROP TABLE public.purchases;
DROP SEQUENCE public.purchase_items_id_seq;
DROP TABLE public.purchase_items;
DROP SEQUENCE public.products_id_seq;
DROP TABLE public.products;
DROP EXTENSION hstore;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: products; Type: TABLE; Schema: public; Owner: craig; Tablespace: 
--

CREATE TABLE products (
    id integer NOT NULL,
    title character varying(255),
    price numeric,
    created_at timestamp with time zone,
    deleted_at timestamp with time zone,
    tags character varying(255)[]
);


ALTER TABLE public.products OWNER TO craig;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: craig
--

CREATE SEQUENCE products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO craig;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: craig
--

ALTER SEQUENCE products_id_seq OWNED BY products.id;


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: craig; Tablespace: 
--

CREATE TABLE purchase_items (
    id integer NOT NULL,
    purchase_id integer,
    product_id integer,
    price numeric,
    quantity integer,
    state character varying(255)
);


ALTER TABLE public.purchase_items OWNER TO craig;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: craig
--

CREATE SEQUENCE purchase_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_items_id_seq OWNER TO craig;

--
-- Name: purchase_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: craig
--

ALTER SEQUENCE purchase_items_id_seq OWNED BY purchase_items.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: craig; Tablespace: 
--

CREATE TABLE purchases (
    id integer NOT NULL,
    created_at timestamp with time zone,
    name character varying(255),
    address character varying(255),
    state character varying(2),
    zipcode integer,
    user_id integer
);


ALTER TABLE public.purchases OWNER TO craig;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: craig
--

CREATE SEQUENCE purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchases_id_seq OWNER TO craig;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: craig
--

ALTER SEQUENCE purchases_id_seq OWNED BY purchases.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: craig; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying(255),
    password character varying(255),
    details hstore,
    created_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO craig;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: craig
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO craig;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: craig
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: craig
--

ALTER TABLE ONLY products ALTER COLUMN id SET DEFAULT nextval('products_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: craig
--

ALTER TABLE ONLY purchase_items ALTER COLUMN id SET DEFAULT nextval('purchase_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: craig
--

ALTER TABLE ONLY purchases ALTER COLUMN id SET DEFAULT nextval('purchases_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: craig
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: craig
--

COPY products (id, title, price, created_at, deleted_at, tags) FROM stdin;
\.
COPY products (id, title, price, created_at, deleted_at, tags) FROM '$$PATH$$/2099.dat';

--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: craig
--

SELECT pg_catalog.setval('products_id_seq', 20, true);


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: craig
--

COPY purchase_items (id, purchase_id, product_id, price, quantity, state) FROM stdin;
\.
COPY purchase_items (id, purchase_id, product_id, price, quantity, state) FROM '$$PATH$$/2101.dat';

--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: craig
--

SELECT pg_catalog.setval('purchase_items_id_seq', 1458, true);


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: craig
--

COPY purchases (id, created_at, name, address, state, zipcode, user_id) FROM stdin;
\.
COPY purchases (id, created_at, name, address, state, zipcode, user_id) FROM '$$PATH$$/2103.dat';

--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: craig
--

SELECT pg_catalog.setval('purchases_id_seq', 1000, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: craig
--

COPY users (id, email, password, details, created_at, deleted_at) FROM stdin;
\.
COPY users (id, email, password, details, created_at, deleted_at) FROM '$$PATH$$/2105.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: craig
--

SELECT pg_catalog.setval('users_id_seq', 50, true);


--
-- Name: products_pkey; Type: CONSTRAINT; Schema: public; Owner: craig; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: craig; Tablespace: 
--

ALTER TABLE ONLY purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: craig; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: purchase_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: craig
--

ALTER TABLE ONLY purchase_items
    ADD CONSTRAINT purchase_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES products(id);


--
-- Name: purchase_items_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: craig
--

ALTER TABLE ONLY purchase_items
    ADD CONSTRAINT purchase_items_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES purchases(id);


--
-- Name: purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: craig
--

ALTER TABLE ONLY purchases
    ADD CONSTRAINT purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

